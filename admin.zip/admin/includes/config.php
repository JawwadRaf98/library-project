<?php
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $database = 'library';

    $connection = mysqli_connect($host,$user,$password,$database) or die("Connection Failed");

?>